@echo off
zig ar %*
