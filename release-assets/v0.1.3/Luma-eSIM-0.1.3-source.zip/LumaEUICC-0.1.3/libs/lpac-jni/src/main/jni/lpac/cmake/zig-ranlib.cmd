@echo off
zig ranlib %*
