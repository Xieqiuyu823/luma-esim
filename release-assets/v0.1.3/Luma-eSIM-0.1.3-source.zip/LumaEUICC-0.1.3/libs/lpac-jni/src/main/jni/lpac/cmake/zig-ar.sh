#!/bin/sh
zig ar "$@"
