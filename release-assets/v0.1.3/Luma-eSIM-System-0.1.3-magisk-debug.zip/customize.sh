TMP_FILE="$TMPDIR/LumaEUICC"

chmod u+x "$MODPATH/uninstall.sh"
cp "$MODPATH/system/system_ext/priv-app/LumaEUICC/LumaEUICC.apk" "$TMP_FILE"

pm install -r "$TMP_FILE"
rm -f "$TMP_FILE"

pm grant "io.luma.euicc" android.permission.READ_PHONE_STATE